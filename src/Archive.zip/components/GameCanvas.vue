<script setup lang="ts">
import { Game } from "@/engine/core/Game"
import { onBeforeMount, onMounted, ref } from "vue"

const canvas = ref<HTMLCanvasElement>()
let game: Game

onMounted(async () => {
  if (!canvas.value) return

  canvas.value.width = 480
  canvas.value.height = 320

  game = new Game(canvas.value)
  await game.start()
})

onBeforeMount(() => {
  // game.stop()
})
</script>

<template>
  <canvas ref="canvas"></canvas>
</template>

<style scoped>
canvas {
  /* position: absolute;
  left: 138px;
  width: 625px; */
  width: 100%;
  height: 100%;
}
</style>