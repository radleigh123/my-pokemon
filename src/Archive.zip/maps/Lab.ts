import { AssetManager } from "@/engine/assets/AssetManager";
import { TileMap } from "@/engine/map/TileMap";

import lab from "@/assets/maps/lab.png";
import { TileType } from "@/engine/map/TileType";

export async function createLab(assets: AssetManager): Promise<TileMap> {
  const image = await assets.loadImage(lab);

  const tiles: TileType[][] = [[TileType.Wall, TileType.Wall]];

  return new TileMap(image, 209, 208, tiles);
}
